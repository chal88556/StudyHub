package com.example.WebChat.Controller;

public class ChatHistoryController {
    // Not implemented or empty in your original code
}
